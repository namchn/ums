package com.nc.ums.domain;

public enum LoanState {
    ACTIVE,
    DELINQUENT,
    IN_COLLECTION,
    FORGIVEN,
    CHARGED_OFF
}
